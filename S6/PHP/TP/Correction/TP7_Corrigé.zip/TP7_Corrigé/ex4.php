<?php
class form {
    protected $code;

    public function __construct($action, $titre) {
        $this->code = "<form action='$action' method='post'>";
        $this->code .= "<fieldset><legend>$titre</legend>";
    }

    public function settext($nom, $label) {
        $this->code .= "$label : <input type='text' name='$nom'><br />";
    }

    public function setsubmit($valeur = "Envoyer") {
        $this->code .= "<input type='submit' value='$valeur'>";
    }

    public function getform() {
        return $this->code . "</fieldset></form>";
    }
}

// Test
$f = new form("traitement.php", "Contact");
$f->settext("nom", "Nom");
$f->settext("email", "Email");
$f->setsubmit();
echo $f->getform();
?>