<?php
class Ville {
    public $nom;
    public $region;

    public function __construct($nom, $region) {
        $this->nom = $nom;
        $this->region = $region;
    }

    public function afficher() {
        echo "La ville {$this->nom} est dans la région {$this->region}.<br />";
    }
}

$ville2 = new Ville("Marrakech", "Marrakech-Safi");
$ville2->afficher();
?>