<?php
abstract class PersonneAbstraite {
    protected $nom;
    protected $prenom;

    public function __construct($nom, $prenom) {
        $this->nom = $nom;
        $this->prenom = $prenom;
    }
}

class Client extends PersonneAbstraite {
    private $adresse;

    public function __construct($nom, $prenom, $adresse) {
        parent::__construct($nom, $prenom);
        $this->adresse = $adresse;
    }

    public function setcoord() {
        echo "Client : {$this->prenom} {$this->nom}, Adresse : {$this->adresse}<br>";
    }
}


class Electeur extends PersonneAbstraite {
    public $nom;
    public $prenom;
    public $bureau_de_vote;
    public $vote = false;

    public function __construct($nom, $prenom, $bureau) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->bureau_de_vote = $bureau;
    }

    public function avoter() {
        $this->vote = true;
    }
}

// Test
$c = new Client("Benahmed", "Soukaina", "Marrakech");
$c->setcoord();

$e = new Electeur("Oussama", "Ait", "Bureau n°5");
$e->avoter();
echo "L'électeur {$e->prenom} {$e->nom} a voté : " . ($e->vote ? "Oui" : "Non");
?>