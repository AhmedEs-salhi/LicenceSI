<?php
require("ex4.php");
class form2 extends form {
    public function setradio($nom, $valeur, $label) {
        $this->code .= "$label : <input type='radio' name='$nom' value='$valeur'><br />";
    }

    public function setcheckbox($nom, $label) {
        $this->code .= "$label : <input type='checkbox' name='$nom'><br />";
    }
}

$f2 = new form2("test.php", "Sondage");
$f2->settext("pseudo", "Pseudo");
$f2->setradio("sexe", "H", "Homme");
$f2->setradio("sexe", "F", "Femme");
$f2->setcheckbox("newsletter", "S'abonner");
$f2->setsubmit("Valider");
echo $f2->getform();
?>