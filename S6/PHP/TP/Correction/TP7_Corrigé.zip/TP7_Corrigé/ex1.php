<?php
class Ville {
    public $nom;
    public $region;

    public function afficher() {
        echo "La ville {$this->nom} est dans la région {$this->region}.<br />";
    }
}

$ville1 = new Ville();
$ville1->nom = "Marrakech";
$ville1->region = "Marrakech-Safi";
$ville1->afficher();
?>