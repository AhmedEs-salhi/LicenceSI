<?php
class Personne {
    private $nom;
    private $prenom;
    private $adresse;

    public function __construct($nom, $prenom, $adresse) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->adresse = $adresse;
    }

    public function __destruct() {
        echo "L'objet {$this->prenom} a été supprimé.<br />";
    }

    public function getpersonne() {
        return "{$this->prenom} {$this->nom}, résidant au : {$this->adresse}<br />";
    }

    public function setadresse($nouvelleAdresse) {
        $this->adresse = $nouvelleAdresse;
    }
}

$p = new Personne("Kacimi", "Ahmed", "10 rue Agdal");
echo $p->getpersonne();
$p->setadresse("25 avenue des Fleurs");
echo "Après déménagement : " . $p->getpersonne();
?>