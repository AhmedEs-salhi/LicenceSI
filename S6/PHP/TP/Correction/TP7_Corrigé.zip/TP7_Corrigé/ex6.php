<?php
require("ex5.php");
$original = new form2("save.php", "Original");
$original->settext("nom", "Nom");

$copie = clone $original;
$copie->settext("prenom", "Prénom");

echo "<h3>Formulaire 1 (Original) :</h3>" . $original->getform();
echo "<h3>Formulaire 2 (Cloné et modifié) :</h3>" . $copie->getform();
?>