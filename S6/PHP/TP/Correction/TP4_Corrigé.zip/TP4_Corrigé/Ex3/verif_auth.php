<?php
	session_start();
	@$login=$_POST["login"];
	@$pwd=$_POST["pwd"];
	@$connexion=$_POST["connexion"];
	$erreur="";
	if(isset($connexion)){
		if($login=="myuser" && $pwd=="mypw"){
			$_SESSION["ok"] = "ok";
			$_SESSION["login"] = $login;
			header("location:contenu.php");
		}
		else{
			$erreur= "login/pwd invalide";
			header("Location: authentif.php?erreur=".$erreur);
		}
	}
 ?>