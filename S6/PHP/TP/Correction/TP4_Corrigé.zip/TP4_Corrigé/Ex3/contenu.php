<?php
	session_start();
	if(@$_SESSION["ok"]!="ok"){
		header("location:authentif.php");
	}
?>
<h1>Bienvenue dans notre site <?php echo $_SESSION["login"]; ?></h1>
<a href="deconnexion.php">Deconnexion</a>