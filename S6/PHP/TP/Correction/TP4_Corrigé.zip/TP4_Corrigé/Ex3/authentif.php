<h1>Page de connexion</h1>

<form action="verif_auth.php" method="post">
	Login <input type="text" name="login" /> <br />
	Password <input type="text" name="pwd" /> <br />
	<input type="submit" name="connexion" value="Login" /> <br />
	<p><?php echo @$_GET["erreur"];?></p>
</form>