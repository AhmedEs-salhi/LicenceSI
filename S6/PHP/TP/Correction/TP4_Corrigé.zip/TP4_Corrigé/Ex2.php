<?php

$heure = date("d/m/Y H:i:s");

if (!isset($_COOKIE["visites"])) {

    // première visite
    setcookie("visites", $heure, time()+3600*24*30);

    echo "C'est votre première visite : ".$heure;

} 
else {
    $liste = $_COOKIE["visites"];
    $visites = explode("|", $liste);
    $visites[] = $heure;
    $nouvelle_liste = implode("|", $visites);
    setcookie("visites", $nouvelle_liste, time()+3600*24*30);
    echo "Vous êtes venu ".count($visites)." fois, voici le détail : <br />";
    echo "<ul>";
    foreach($visites as $v){
        echo "<li>le ".$v."</li>";
    }
    echo "</ul>";
}
?>