    <h2>Choisissez vos couleurs préférées</h2>
    <form method="post" action="">
        Couleur de fond :<input type="color" name="fond" required><br /><br />
        Couleur du texte :<input type="color" name="texte" required><br /><br />
        <input type="submit" name="enregistrer" value="Enregistrer">
    </form>
<?php
    @$fond = $_POST["fond"];
    @$texte = $_POST["texte"];
	@$enregistrer = $_POST["enregistrer"];
	if(isset($enregistrer)){
		setcookie("couleur_fond", $fond, time() + 24*2*30*3600);
		setcookie("couleur_texte", $texte, time() + 24*2*30*3600);
		header("Location: accueil.php");
	}
?>