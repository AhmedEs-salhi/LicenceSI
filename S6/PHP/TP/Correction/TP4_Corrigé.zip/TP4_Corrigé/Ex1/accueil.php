<?php
$fond = "#ffffff";   // valeur par défaut
$texte = "#000000";  // valeur par défaut

if (isset($_COOKIE["couleur_fond"])) {
    $fond = $_COOKIE["couleur_fond"];
}

if (isset($_COOKIE["couleur_texte"])) {
    $texte = $_COOKIE["couleur_texte"];
}
?>
<head>
    <style>
        body {
            background-color: <?php echo $fond; ?>;
            color: <?php echo $texte; ?>;
            font-family: Arial, sans-serif;
            padding: 20px;
        }
    </style>
</head>
<body>
    <h1>Bienvenue sur la page d'accueil</h1>
    <p>Cette page utilise vos couleurs préférées enregistrées dans les cookies.</p>

    <a href="form.php">Modifier les couleurs</a>
</body>
</html>