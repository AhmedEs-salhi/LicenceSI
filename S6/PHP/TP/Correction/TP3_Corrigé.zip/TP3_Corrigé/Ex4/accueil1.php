<?php

@$nom = $_POST["nom"];
@$prenom = $_POST["prenom"];

if ($nom != "" && $prenom != "") {
    echo "Bonjour $prenom $nom ";
}
else {
    if ($nom == "" && $prenom == "")
        echo "<font color='red'>Erreur : le nom et le prénom sont obligatoires</font>";
    elseif ($nom == "")
        echo "<font color='red'>Erreur : le nom est obligatoire</font>";
    else
        echo "<font color='red'>Erreur : le prénom est obligatoire</font>";
}

?>

<br />
<a href="login1.php">Retour</a>