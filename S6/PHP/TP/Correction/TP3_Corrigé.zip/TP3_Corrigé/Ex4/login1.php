<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>Connexion</h2>

<form method="post" action="accueil1.php">
    Nom : <input type="text" name="nom"><br /><br />
    Prénom : <input type="text" name="prenom"> <br /><br />
    <input type="submit" value="OK">
</form>

</body>
</html>