<form method="post" action="accueil2.php">

    Nom : <input type="text" name="nom"><br /><br />
    Prénom : <input type="text" name="prenom"><br /><br />
    Sexe :
    <select name="sexe">
        <option value="">----------</option>
        <option value="M">Masculin</option>
        <option value="F">Féminin</option>
    </select>
    <br /><br />
    <input type="submit" value="OK">
</form>