<?php

@$nom = $_POST["nom"];
@$prenom = $_POST["prenom"];
@$sexe = $_POST["sexe"];

if ($nom != "" && $prenom != "" && $sexe != "") {
    if ($sexe == "M")    $civilite = "Monsieur";
	else  $civilite = "Madame";
    echo "Bonjour $civilite $nom";

} else {
    if ($nom == "" && $prenom == "" && $sexe == "")
        echo "<font color='red'>Erreur : tous les champs sont obligatoires.</font>";
    elseif ($nom == "")
        echo "<font color='red'>Erreur : le nom est obligatoire.</font>";
    elseif ($prenom == "")
        echo "<font color='red'>Erreur : le prénom est obligatoire.</font>";
    else  echo "<font color='red'>Erreur : vous devez sélectionner votre sexe.</p>";

}

?>

<br />
<a href="login2.php">Retour</a>
