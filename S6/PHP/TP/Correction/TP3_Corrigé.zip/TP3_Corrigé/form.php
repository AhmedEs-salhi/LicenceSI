<form method="post" action="traitement.php">

    Nom : <input type="text" name="nom"><br /><br />
    Prénom : <input type="text" name="prenom"><br /><br />
    Date de naissance : <input type="date" name="date_naissance"><br /><br />
    <input type="submit" value="Envoyer">

</form>