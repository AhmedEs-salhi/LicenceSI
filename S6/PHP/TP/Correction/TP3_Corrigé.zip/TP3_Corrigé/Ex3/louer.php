<!DOCTYPE html>
<html>
<head>
    <title>Louer</title>
</head>
<body>

<h2>Vous souhaitez louer un bien</h2>

<a href="index.php">Retour à l'accueil</a>

</body>
</html>