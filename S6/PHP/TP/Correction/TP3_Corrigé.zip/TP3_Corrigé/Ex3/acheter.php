<!DOCTYPE html>
<html>
<head>
    <title>Acheter</title>
</head>
<body>

<h2>Vous souhaitez acheter un bien</h2>

<a href="index.php">Retour à l'accueil</a>

</body>
</html>