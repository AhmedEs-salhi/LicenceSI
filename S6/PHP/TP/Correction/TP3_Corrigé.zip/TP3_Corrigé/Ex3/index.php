<?php

if (isset($_POST["vendre"])) {
    header("Location: vendre.php");
    exit;
}

if (isset($_POST["acheter"])) {
    header("Location: acheter.php");
    exit;
}

if (isset($_POST["louer"])) {
    header("Location: louer.php");
    exit;
}

?>
<form method="post">
    <input type="submit" name="vendre" value="Vendre">
    <input type="submit" name="acheter" value="Acheter">
    <input type="submit" name="louer" value="Louer">
</form>