<!DOCTYPE html>
<html>
<head>
    <title>Vendre</title>
</head>
<body>

<h2>Vous souhaitez vendre votre bien</h2>

<a href="index.php">Retour à l'accueil</a>

</body>
</html>