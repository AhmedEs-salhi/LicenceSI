<?php

@$nom = $_POST["nom"];
@$prenom = $_POST["prenom"];
@$date_naissance = $_POST["date_naissance"];

if ($nom != "" && $prenom != "" && $date_naissance != "") {
    $annee_actuelle = date("Y");
    $annee_naissance = date("Y", strtotime($date_naissance));
    $age = $annee_actuelle - $annee_naissance;
    echo "Bonjour : $prenom $nom<br>";
    echo "Vous êtes né en $annee_naissance<br>";
    echo "Nous sommes en $annee_actuelle<br>";
    echo "Vous avez donc environ $age ans<br><br>";

    if ($age >= 1 && $age <= 120) echo "<b> L'âge est correct</b>";
    else echo "<b style='color:red'>L'âge est incorrect</b>";
} else {
    echo "<font color='red'>Erreur : Tous les champs sont obligatoires</font>";
}

?>

<br /><br />
<a href="formulaire.php">Retour</a>
