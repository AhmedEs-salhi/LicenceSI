<?php
$prixHT = "";
$tauxTVA = "";
$montantTVA = "";
$prixTTC = "";

if (isset($_POST["calculer"])) {

    $prixHT = $_POST["prixHT"];
    $tauxTVA = $_POST["tauxTVA"];

    if (is_numeric($prixHT) && is_numeric($tauxTVA)) {
        $montantTVA = $prixHT * $tauxTVA / 100;
        $prixTTC = $prixHT + $montantTVA;
    } else {
        echo "<font color='red'>Veuillez saisir des nombres valides.</font>";
    }
}
?>

<h2>Calcul de la TVA</h2>
<form method="post" action="">
    Prix HT : <input type="text" name="prixHT" value="<?php echo $prixHT; ?>">
    <br /><br />

    Taux TVA (%) : <input type="text" name="tauxTVA" value="<?php echo $tauxTVA; ?>">
    <br /><br />
    <input type="submit" name="calculer" value="Calculer">
    <input type="reset" value="Effacer">
    <br /><br />

    <?php
    if ($montantTVA != "") {
        echo "Montant TVA : <input type='text' value='$montantTVA'><br><br>";
        echo "Prix TTC : <input type='text' value='$prixTTC'>";
    }
    ?>
</form>