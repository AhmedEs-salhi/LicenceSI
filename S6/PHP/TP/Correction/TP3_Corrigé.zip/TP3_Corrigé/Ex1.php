<form action="" method="post">
<fieldset>
	<legend><b>Saisissez vos coordonnées </b></legend>
	<table border="0" >
		<tr>
			<td>Nom : </td>
			<td><input type="text" name="nom" /></td>
		</tr>
		<tr>
			<td>Prénom : </td>
			<td> <input type="text" name="prenom" /></td>
		</tr>
		<tr>
			<td>Adresse : </td>
			<td><input type="text" name="adresse" /></td>
		</tr>
		<tr>
			<td>Ville :</td>
			<td><input type="text" name="ville" /></td>
		</tr>
		<tr>
			<td>Code postal :</td>
			<td><input type="text" name="code" maxlength="5"/></td>
		</tr>
		<tr>
			<td>CONFIRMER</td>
			<td><input type="submit" value="ENVOI" /></td>
		</tr>
	</table>
</fieldset>
</form>
<?php
	echo "<table border=\"1\" >";
	echo "<caption><b>Confirmation de vos coordonnées</b></caption>";
	foreach($_POST as $cle=>$val){
		echo "<tr> <td> $cle : &nbsp;</td> <td>".$val."</td></tr>";
	}
	echo "</table>";
?>