<?php
$csvFile = "dons.csv";
$txtFile = "dons.txt";

$erreurs = [];
$success = "";

@$nomprenom = $_POST["nomprenom"];
@$datenaissance = $_POST["datenaissance"];
@$mail = $_POST["mail"];
@$don = $_POST["don"];

if(isset($_POST["valider"])){
    if ($nomprenom == "") {
        $erreurs[] = "Le champ Nom & prénom est obligatoire.";
    }
    if ($datenaissance == "") {
        $erreurs[] = "Le champ Date de naissance est obligatoire.";
    }
    if ($mail == "") {
        $erreurs[] = "Le champ Mail est obligatoire.";
    } 
    if ($don == "") {
        $erreurs[] = "Le champ Valeur du don est obligatoire.";
    } 

    if (empty($erreurs)) {
        $fichier = fopen($csvFile, "a");
        if ($fichier) {
            $ligne = [$nomprenom, $datenaissance, $mail, $don];
            fputcsv($fichier, $ligne, ";");
            fclose($fichier);

            $success = "Don enregistré avec succès.";

        } else {
            $erreurs[] = "Impossible d'ouvrir le fichier CSV.";
        }
    }
}

/* 2) Lire le CSV pour afficher les données et calculer les statistiques */
$dons = [];
$totalDons = 0;
$nombreDonateurs = 0;

if (file_exists($csvFile)) {
    $fichier = fopen($csvFile, "r");

    if ($fichier) {
        while (($ligne = fgetcsv($fichier, 0, ";")) !== false) {
            if (count($ligne) >= 4) {
                $dons[] = $ligne;
                $totalDons += (float)$ligne[3];
                $nombreDonateurs++;
            }
        }
        fclose($fichier);
    }
}

$contenuTxt = "Nombre total de donateurs : " . $nombreDonateurs;
$contenuTxt .= "Somme totale des dons : " . $totalDons . " DH";

file_put_contents($txtFile, $contenuTxt);
?>

    <h2>Formulaire de don</h2>

    <?php
    if (!empty($erreurs)) {
        foreach ($erreurs as $e) {
            echo $e . "<br />";
        }
    }

    if ($success != "") {
        echo $success;
    }
    ?>

    <form method="post" action="">
        <p>
            <label>Nom & prénom :</label>
            <input type="text" name="nomprenom" />
        </p>

        <p>
            <label>Date de naissance :</label>
            <input type="date" name="datenaissance" />
        </p>

        <p>
            <label>Mail :</label>
            <input type="text" name="mail" />
        </p>

        <p>
            <label>Valeur du don (DH) :</label>
            <input type="text" name="don" />
        </p>

        <p>
            <input type="submit" name="valider" value="OK" />
        </p>
    </form>

    <h2>Liste des dons enregistrés</h2>

    <table>
        <tr>
            <th>Nom & prénom</th>
            <th>Date de naissance</th>
            <th>Mail</th>
            <th>Don (DH)</th>
        </tr>

        <?php
        if (!empty($dons)) {
            foreach ($dons as $ligne) {
                echo "<tr>";
                echo "<td>" . $ligne[0] . "</td>";
                echo "<td>" . $ligne[1] . "</td>";
                echo "<td>" . $ligne[2] . "</td>";
                echo "<td>" . $ligne[3] . "</td>";
                echo "</tr>";
            }
        } else {
            echo '<tr><td>Aucun don enregistré.</td></tr>';
        }
        ?>
    </table>

        <strong>Résumé :</strong><br>
        Nombre total de donateurs : <?php echo $nombreDonateurs; ?><br>
        Somme totale des dons : <?php echo $totalDons; ?> DH