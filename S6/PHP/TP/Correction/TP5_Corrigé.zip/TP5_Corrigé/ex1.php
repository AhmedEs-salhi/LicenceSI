<?php 
$fichier = "compteur.txt";
if(!file_exists($fichier)){
    file_put_contents($fichier,0);
}
$visites = file_get_contents($fichier);
if($visites == ""){
    $visites = 0;
}
$visites++;
file_put_contents($fichier,$visites);
echo "Nombre de visites : ".$visites;
?>
