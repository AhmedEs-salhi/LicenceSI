<?php

$fichier = fopen("contacts.txt","r+");
while(($ligne = fgets($fichier)) != false){
    $contact = explode("|",$ligne);
    echo "Nom : ".trim($contact[0])."<br />";
    echo "Prénom : ".trim($contact[1])."<br />";
    echo "Adresse : ".trim($contact[2])."<br />";
    echo "CP : ".trim($contact[3])."<br />";
    echo "Ville : ".trim($contact[4])."<br />";
	echo "<hr />";
}

fclose($fichier);

?>