<?php
require("connexion.php");

$message = "";
@$titre = $_POST["titre"]);
@$description = $_POST["description"]);)
@$date_limite = $_POST["date_limite"];
@$priorite = $_POST["priorite"];
	
if (isset($_POST["ajout"])) {
    
    $date_creation = date("Y-m-d");
    $statut = "à faire";

    if (empty($titre) || empty($date_limite) || empty($priorite)) {
        $message = "Le titre, la date limite et la priorité sont obligatoires.";
    } else {
        try {
            $req = "INSERT INTO tache (titre, description, date_creation, date_limite, priorite, statut)
                    VALUES (?, ?, ?, ?, ?, ?)";
            $res = $pdo->prepare($req);
            $res->execute([$titre, $description, $date_creation, $date_limite, $priorite, $statut]);

            $message = "Tâche ajoutée avec succès.";
        } catch (PDOException $e) {
            $message = "Erreur : " . $e->getMessage();
        }
    }
}
?>
<h2>Ajouter une tâche</h2>

    <form method="post" action="">
        <label>Titre :</label>
        <input type="text" name="titre"><br /><br />

        <label>Description :</label>
        <textarea name="description"></textarea><br /><br />

        <label>Date limite :</label>
        <input type="date" name="date_limite"><br /><br />

        <label>Priorité :</label>
        <select name="priorite">
            <option value="">-- Choisir --</option>
            <option value="faible">Faible</option>
            <option value="moyenne">Moyenne</option>
            <option value="haute">Haute</option>
        </select><br /><br />

        <input type="submit" name="ajout" value="Ajouter">
    </form>

    <p><?php echo $message; ?></p>

    <a href="affichage.php">Voir la liste des tâches</a>
