<?php
require("connexion.php");

try {
    $req = $pdo->query("SELECT * FROM tache ORDER BY id DESC");
    $taches = $req->fetchAll(PDO::FETCH_ASSOC);

    $total = $pdo->query("SELECT COUNT(*) AS nb FROM tache")->fetch(PDO::FETCH_ASSOC);
    $terminees = $pdo->query("SELECT COUNT(*) AS nb FROM tache WHERE statut = 'terminée'")->fetch(PDO::FETCH_ASSOC);
    $enCours = $pdo->query("SELECT COUNT(*) AS nb FROM tache WHERE statut = 'en cours'")->fetch(PDO::FETCH_ASSOC);
    $aFaire = $pdo->query("SELECT COUNT(*) AS nb FROM tache WHERE statut = 'à faire'")->fetch(PDO::FETCH_ASSOC);
    $prioHaute = $pdo->query("SELECT COUNT(*) AS nb FROM tache WHERE priorite = 'haute'")->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>

<h2>Liste des tâches</h2>

    <table border="1" cellpadding="8" cellspacing="0">
        <tr>
            <th>ID</th>
            <th>Titre</th>
            <th>Description</th>
            <th>Date création</th>
            <th>Date limite</th>
            <th>Priorité</th>
            <th>Statut</th>
            <th>Actions</th>
        </tr>

        <?php foreach ($taches as $tache) { ?>
            <tr>
                <td><?php echo $tache["id"]; ?></td>
                <td><?php echo $tache["titre"]; ?></td>
                <td><?php echo $tache["description"]; ?></td>
                <td><?php echo $tache["date_creation"]; ?></td>
                <td><?php echo $tache["date_limite"]; ?></td>
                <td><?php echo $tache["priorite"]; ?></td>
                <td><?php echo $tache["statut"]; ?></td>
                <td>
                    <a href="modifier.php?id=<?php echo $tache['id']; ?>">Modifier</a> |
                    <a href="supprimer.php?id=<?php echo $tache['id']; ?>" onclick="return confirm('Supprimer cette tâche ?');">Supprimer</a> |
                    <a href="changer_statut.php?id=<?php echo $tache['id']; ?>">Changer statut</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <h3>Statistiques</h3>
    <p>Nombre total des tâches : <?php echo $total["nb"]; ?></p>
    <p>Nombre de tâches terminées : <?php echo $terminees["nb"]; ?></p>
    <p>Nombre de tâches en cours : <?php echo $enCours["nb"]; ?></p>
    <p>Nombre de tâches à faire : <?php echo $aFaire["nb"]; ?></p>
    <p>Nombre de tâches de priorité haute : <?php echo $prioHaute["nb"]; ?></p>

    <br />
    <a href="ajout.php">Ajouter une tâche</a> |
    <a href="recherche.php">Rechercher une tâche</a>